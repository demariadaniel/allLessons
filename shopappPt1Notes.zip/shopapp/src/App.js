import React, { Component } from "react";
import { Switch, Route, Link } from "react-router";
import Shop from "./components/Shop";
import Splash from './components/Splash';
import logo from "./logo.svg";
import "./App.css";

class App extends Component {
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to the Shop</h1>
        </header>
        <div>
          <Switch>
            {/* We place our Splash Page and our Shop Page at the same
              level so that only one of the two is ever displayed */}
            <Route 
              exact
              path="/"
              render={()=>(<Splash />)}
            />
            <Route
              path="/shop"
              render={routeProps => <Shop {...routeProps} />}
            />
            {/* routeProps are props supplied by React router -- match,
              Location, History -- so any time you hope to use them
              inside of the render propr on a Route, you pass them in like
              this. Include them as an argument to the render arrow
              function, and pass them in as props to the component
              that gets rendered. */}
          </Switch>
        </div>
      </div>
    );
  }
}


export default App;
