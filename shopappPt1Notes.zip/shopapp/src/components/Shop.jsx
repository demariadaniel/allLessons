import React, { Component } from "react";
import { Switch, Route, Link } from "react-router-dom";
import Amps from "../data/Amps";
import Guitars from "../data/Guitars";
import Effects from "../data/Effects";
import Cart from './Cart';
import ShopPage from "./ShopPage";
import ItemDetails from "./ItemDetails";

export default class Shop extends Component {
  state = {
    products: [Amps, Guitars, Effects]
  };
  render() {
    const {match} = this.props;
    return (
      <div>
        <nav>
          {/* Dynamically creates links for every product category,
            i.e. Amps, Guitars, Effects. Each link takes us to
            ${match.url}/${product.category}` : the current URL
            '/shop' followed by a '/' followed by the category */}
          {this.state.products.map(product => (
            <Link to={`${match.url}/${product.category}`}>
              <button>{product.category}</button>
            </Link>
          ))}
        </nav>
        <div className="shopPage--parent">
          <Switch className="shopPage--parent">
            {/* We have one Link for each category, and so we need one 
              Route to match! Our reusable ShopPage component creates a
              basic layout for every category. Here we pass in the product
              category and inventory as props ( {...product} ) to render
              inside the ShopPage. We use the 'exact' propd to make sure that
              the ShopPage ONLY shows up if we are at the relevant URL.
              For example, '/shop/guitars' will render a Shop Page, but
              '/shop/guitars/3' will show a Product Details page, because
              this URL does not EXACTLY match this path.  */}
            {this.state.products.map(product => (
              <Route
                exact
                path={`${match.url}/${product.category}`}
                render={routeProps => <ShopPage {...routeProps} {...product} />}
              />
            ))}

            {/* We use the same Switch section to render both our Shop Page
            and our Item Details component. We want them to occupy the same
            space on the page and we only want one to show at a time. The
            Shop Page will render if our URL exactly matches the format
            '/shop/category', but if it contains an item index at the end,
            ItemDetails will render instead. We use the itemIndex parameter
            from the URL to identify which item we want to render on the page.
            See we have a prop for `item`, and the value is equal to:
              product.inventory [ routeProps.match.params.itemIndex ]
              ^^ array of products    ^^ index contained in the URL  */}
            {this.state.products.map(product => (
              <Route
                path={`${match.url}/${product.category}/:itemIndex`}
                render={routeProps => (
                  <ItemDetails
                    {...routeProps}
                    category={product.category}
                    item={
                      product.inventory[
                        routeProps.match.params.itemIndex
                      ]
                    }
                  />
                )}
              />
            ))}
          </Switch>
        </div>
        <Cart />
      </div>
    );
  }
}
