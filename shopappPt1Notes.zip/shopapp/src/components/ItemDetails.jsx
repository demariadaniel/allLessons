import React, { Component } from "react";
import { Link } from "react-router-dom";

// When we write a 'functional component' (a dumb component using a function
// rather than a class) we access Props as arguments in the function
// We can write a single argument like ItemDetails =(props)=> to get
// all props together and access them as keys (i.e. props.item)
// Or we can 'destructure' individual props as their own variable name.
// Here we write ItemDetails =({item, match, category})=>, and now instead of writing
// props.item, we just write item. Useful if you use props in a lot of places
// and want to skip writing props everywhere! The variable name must
// match one of the keys passed down through props for this to work.

const ItemDetails = ({ item, match, category }) => (
  <div className="itemDetails--container">
    <h2>
      {item.brand} {item.model}
    </h2>
    <img 
      className="product--imageSize"
      src={`${process.env.PUBLIC_URL}/images/${item.image}`} />
    <p>{item.price}</p>
    <Link to={`/shop/${category}`}>
      <button>Back</button>
    </Link>
  </div>
);

// In the img src property, process.env.PUBLIC_URL is the path to the 
// 'public' folder. So here we are constructing the URL to '/public/images'
// followed by the unique image path for the given item.

// We also create a 'Back' button by passing in the product category
// and linking to '/shop' followed by that category

export default ItemDetails;
