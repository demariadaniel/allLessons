import React, { Component } from "react";
import { Link } from "react-router-dom";

// For info on the =({inventory, match, category})=> syntax see ItemDetails

// Our ShopPage component displays all the items for a given category. 
// Each item can be clicked on to display a specific ItemDetails page,
// using a Link. Each Link takes us to `${match.url}/${i}`.
// ${match.url} represents the current URL (i.e. '/shop/Guitars/').
// ${i} is the item's index. The ItemDetails route on our Shop component 
// uses i to determine which item to render.

const ShopPage = ({ inventory, match, category }) => (
  <div>
    <h3>{category}</h3>
    <div class="shopPage--container">
      {inventory.map((item, i) => (
        <Link to={`${match.url}/${i}`}>
          <div class="shopPage--item">
            <p>
              {item.brand} {item.model}
            </p>
            <p>{item.price}</p>
          </div>
        </Link>
      ))}
    </div>
  </div>
);

export default ShopPage;
