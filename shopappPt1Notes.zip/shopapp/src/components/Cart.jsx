import React, { Component } from "react";

const Cart =()=>(
  <div className="cart">
    <h3>Cart</h3>
    <p>Subtotal: $0</p>
  </div>
)

export default Cart;