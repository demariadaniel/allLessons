import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import axios from 'axios';

class App extends Component {
  state = {
    users: [],
    newUser: {
      email: "",
      address: "",
      age: 0
    }
  }
  addUser =()=>{
    // This function sends our newUser object to be added to the database
    axios.post('http://localhost:8080/users', this.state.newUser)
      .then(res=>{
        console.log(res.data)
      })
  }
  editUser =(event, key)=> {
    // This function is written in a way that we can use it to update all fields
    // of our newUser with a single function. event supplies the user's input
    // and key specifies which field is being updated.
    let newUser = { ...this.state.newUser };
    newUser[key] = key === "age" ? 
      parseInt(event.target.value) : event.target.value;
    // This is a fancy way of updating our newUser object which takes advantage
    // of ternary operators.  If we are updating the 'age' property, we 
    // parse our user input to a number; otherwise we save event.target.value
    // as is.
    this.setState({
      newUser: newUser
    }, ()=> console.log(this.state))
    // this.setState takes a callback function as an argument, which will
    // run as soon as state is finished updating.
  }
  getUsers =()=>{
    axios.get('http://localhost:8080/users')
      .then(res => {
        console.log(res.data)
        this.setState({
          users: res.data
        })
      })
  }
  render() {
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h1 className="App-title">Welcome to React</h1>
        </header>
        <div>
          <button onClick={this.getUsers}>
            Get Users
          </button>
          {this.state.users.map(user => (
              <div>
                <h3>{user.email}</h3>
              </div> 
            ))
          }
        </div>
        <div>
          <h2>Make User</h2>
          <p>Email</p>
          <input 
            value={this.state.newUser.email}
            onChange={(e)=> this.editUser(e, 'email')}/>
          {/* To make our editUser function work, we need an argument
            specifying which key is being updated, as well as the 
            event object which contains the user's input data     */}
          <p>Address</p>
          <input 
            value={this.state.newUser.address}
            onChange={(e)=> this.editUser(e, 'address')}/>
          <p>Age</p>
          <input 
            type="number"
            value={this.state.newUser.age}
            onChange={(e)=> this.editUser(e, 'age')}/>
          <button onClick={this.addUser}>
            Make User
          </button>
        </div>
      </div>
    );
  }
}

export default App;
