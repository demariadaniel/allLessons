SETTING UP MONGO DB

1) `npm install --save mongodb mongoose` in your backend/api/server folder

2) `mkdir -p data/db` also in your server folder. This creates a folder called 'data' containing another folder called 'db'.

3) Open 3 terminal tabs -- one for your node server, one for your mongo server, one for your react server

4) `mongod --dbpath data/db` will launch your mongo server. You may need to replace `mongod` with the path to the mongod.exe file

5) Copy the mongoose starter code in to your Node server

6) Create a 'models' folder in your API folder and your first Schema/Model file. Import this module into your Node server.

7) You are now ready to launch your Node server and to start writing Mongoose queries!