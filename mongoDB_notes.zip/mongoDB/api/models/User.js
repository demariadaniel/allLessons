const mongoose = require('mongoose');
const Schema = mongoose.Schema;

// Create a schema.
const userSchema = new Schema({
  email: String,
  address: {
    type: String,
    required: true,
    unique: true
  },
  age: Number,
  created_at: Date,
  updated_at: Date
});

// Create a model using schema.
const User = mongoose.model('User', userSchema);

// Make this available to our Node applications.
module.exports = User;