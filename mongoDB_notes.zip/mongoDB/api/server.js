const express = require('express')
const app = express()
const bodyParser =  require('body-parser')

// Boilerplate Mongoose Code
// Establishes connection between Node server and Mongoose server
const mongoose = require('mongoose');
const db = mongoose.connection;
mongoose.connect('mongodb://localhost/data/db/');
mongoose.Promise = global.Promise;
db.on('error', console.error.bind(console, 'connection error:'));
db.once('open', () => {
	console.log("Connected to db at /data/db/")
});

app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Methods", "GET, PUT, POST, DELETE");
  // Add ^^ to allow 'DELETE' requests from front end
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  next();
});
app.use(bodyParser())

app.listen(8080, ()=>{
  console.log('Listening')
})

// Import Model
const User = require('./models/User')

app.get('/users', (req, res)=>{
  // Use our User model to find all users.
  // .find({}) is essentially saying 'find any and all users' -- i.e. we
  // are not specifying any specific user so get all of them.
  // Then, when we get the results, we send it back to the front end.
  User
    .find({})
    .then( users => {
      res.send(users)
    })
})

app.post('/users', (req, res)=>{
  // Here we take the data from our req.body and use to create a new 
  // User object in the database. Then, after we save it to the database,
  // we then find the complete list of ALL users, and send entire collection
  // back to the front end.
  new User(req.body)
    .save()
    .then(user =>{
      User 
        .find({})
        .then( users =>{
          res.send(users)
        })
    })
})